# 🥗 אפליקציית תזונאי — Nutrition AI App

> אפליקציית תזונה חכמה מבוססת ארכיטקטורת מולטי-אגנט עם Claude AI

## 📋 סקירה

אפליקציית תזונאי היא מערכת ניהול תזונה אישית שמשלבת מסד נתוני מזון, מנוע מתכונים, בניית תפריטים אוטומטית, ומעקב יעדים — הכל מתוזמן דרך ארכיטקטורת סוכנים חכמה.

## 🏗️ ארכיטקטורה

המערכת בנויה מ-**10 סוכנים** בשלוש שכבות:

### שכבת נתונים (Data Layer)
| סוכן | תפקיד |
|-------|--------|
| 🗃️ Food Data Agent | מסד נתוני מזון, חיבור USDA API, מטמון מקומי |
| 📖 Recipe Agent | ניהול ויצירת מתכונים, חישוב ערכים למנה |
| 📋 Meal Planner Agent | בניית תפריטים יומיים/שבועיים לפי יעדים |

### שכבת חישובים (Compute Layer)
| סוכן | תפקיד |
|-------|--------|
| 🥗 Nutrition Agent | חישוב ערכים תזונתיים (מאקרו + מיקרו) |
| 🎯 Goals Agent | מעקב יעדים, קלוריות, גירעון/עודף |

### שכבת אינטגרציה + ממשק
| סוכן | תפקיד |
|-------|--------|
| 🔗 Data Sync Agent | ייבוא מ-Cal AI, Apple Health |
| 🖥️ UI Agent | ממשק Flask Web |
| 🔧 Debugger Agent | טסטים, QA |
| 🤖 Orchestrator | ניהול זרימת עבודה בין סוכנים |

## 🔄 זרימת פעולה

```
משתמש מקליד "חזה עוף 200g + אורז 150g"
    │
    ▼
🖥️ UI Agent → מקבל קלט
    │
    ▼
🗃️ Food Data Agent → מזהה מזונות, שולף ערכים מ-USDA/מטמון
    │
    ▼
🥗 Nutrition Agent → מחשב: 330 קל', 62g חלבון, 47g פחמימות
    │
    ▼
🎯 Goals Agent → מעדכן: נשאר 1,870 קל' ליעד היומי
    │
    ▼
📋 Meal Planner → מציע ארוחת ערב שתשלים את המאקרו
```

## 📂 מבנה תיקיות

```
nutrition-app/
├── README.md
├── CLAUDE.md                  # הוראות ראשיות לסוכנים
├── .gitignore
├── docs/
│   ├── architecture.md        # ארכיטקטורה מפורטת
│   └── roadmap.md             # תוכנית עבודה
├── agents/
│   ├── food_data/             # Food Data Agent
│   │   ├── CLAUDE.md
│   │   └── food_data_agent.py
│   ├── recipe/                # Recipe Agent
│   │   ├── CLAUDE.md
│   │   └── recipe_agent.py
│   ├── meal_planner/          # Meal Planner Agent
│   │   ├── CLAUDE.md
│   │   └── meal_planner_agent.py
│   ├── nutrition/             # Nutrition Agent
│   │   ├── CLAUDE.md
│   │   └── nutrition_agent.py
│   ├── goals/                 # Goals Agent
│   │   ├── CLAUDE.md
│   │   └── goals_agent.py
│   ├── data_sync/             # Data Sync Agent
│   │   ├── CLAUDE.md
│   │   └── data_sync_agent.py
│   ├── ui/                    # UI Agent
│   │   ├── CLAUDE.md
│   │   └── ui_agent.py
│   └── debugger/              # Debugger Agent
│       ├── CLAUDE.md
│       └── debugger_agent.py
├── data/
│   ├── foods.db               # SQLite מסד מזון
│   └── israeli_foods.json     # מזונות ישראליים
├── orchestrator/
│   └── workflow_engine.py     # מנוע אורקסטרציה
├── web/
│   ├── app.py                 # Flask server
│   ├── templates/
│   └── static/
├── tests/
│   └── ...
└── requirements.txt
```

## 🛠️ טכנולוגיות

- **Python 3.11+**
- **Flask** — Web UI
- **SQLite** — מסד נתוני מזון מקומי
- **USDA FoodData Central API** — מקור נתונים ראשי
- **Open Food Facts API** — מוצרים ארוזים
- **Claude API** — יצירת מתכונים, ניתוח תמונות

## 🚀 התחלה מהירה

```bash
# שכפל את הפרויקט
git clone https://github.com/USERNAME/nutrition-app.git
cd nutrition-app

# התקן דרישות
pip install -r requirements.txt

# הגדר API keys
cp .env.example .env
# ערוך את .env עם ה-keys שלך

# הרץ
python web/app.py
```

## 📊 מקורות נתונים

| מקור | סוג | עלות |
|------|------|------|
| USDA FoodData Central | 300K+ מזונות עם ערכים מלאים | חינמי (API Key) |
| Open Food Facts | מוצרים ארוזים עם ברקודים | חינמי (Open Source) |
| מסד ישראלי מותאם | חומוס, טחינה, קוטג' תנובה וכו' | בנייה ידנית |

## 📅 סטטוס פיתוח

- [x] Backend workflow engine + 7 agents
- [x] Orchestration engine
- [x] Architecture v2.0 design
- [ ] Food Data Agent + SQLite
- [ ] Recipe Agent
- [ ] Meal Planner Agent
- [ ] Data Sync Agent (Cal AI / Apple Health)
- [ ] Flask Web UI
- [ ] Claude API integration (recipe generation)

## 👥 תורמים

- **Neo** — ארכיטקטורה, עיצוב מערכת, פיתוח

## 📄 רישיון

Private — All rights reserved
